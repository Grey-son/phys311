import { drawHud } from "./hud.js";

export function drawGrid(ctx, canvas, cam, spacing, label) {
  ctx.strokeStyle = "#2f2f2f"; ctx.lineWidth = 1;
  ctx.fillStyle = "#888"; ctx.font = "11px monospace";

  const x0 = Math.ceil(cam.toWorldX(0) / spacing) * spacing;
  const x1 = cam.toWorldX(canvas.width);
  for (let x = x0; x <= x1; x += spacing) {
    const px = cam.toScreenX(x);
    ctx.beginPath(); ctx.moveTo(px, 0); ctx.lineTo(px, canvas.height); ctx.stroke();
    if (Math.abs(x) > 1e-9) ctx.fillText(x.toFixed(label), px + 3, canvas.height - 5);
  }
  const y0 = Math.ceil(cam.toWorldY(canvas.height) / spacing) * spacing;
  const y1 = cam.toWorldY(0);
  for (let y = y0; y <= y1; y += spacing) {
    const py = cam.toScreenY(y);
    ctx.beginPath(); ctx.moveTo(0, py); ctx.lineTo(canvas.width, py); ctx.stroke();
    if (Math.abs(y) > 1e-9) ctx.fillText(y.toFixed(label), 4, py - 4);
  }
  // axes
  ctx.strokeStyle = "#5a5a5a"; ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, cam.toScreenY(0)); ctx.lineTo(canvas.width, cam.toScreenY(0));
  ctx.moveTo(cam.toScreenX(0), 0); ctx.lineTo(cam.toScreenX(0), canvas.height);
  ctx.stroke();
}

export function drawScaleBar(ctx, canvas, cam, metres, text) {
  const px = cam.toScreenLen(metres);
  const x = canvas.width - px - 24, y = 30;
  ctx.strokeStyle = "#fff"; ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x, y); ctx.lineTo(x + px, y);
  ctx.moveTo(x, y - 5); ctx.lineTo(x, y + 5);
  ctx.moveTo(x + px, y - 5); ctx.lineTo(x + px, y + 5);
  ctx.stroke();
  ctx.fillStyle = "#fff"; ctx.font = "12px monospace";
  ctx.textAlign = "center";
  ctx.fillText(text, x + px / 2, y - 10);
  ctx.textAlign = "left";
}

function speedColor(body, maxSpeed) {
  const s = body.vel.length();
  const t = Math.min(s / maxSpeed, 1);

  const r = Math.round(139 * t);
  const g = 0;
  const b = Math.round(139 * (1 - t));

  return `rgb(${r}, ${g}, ${b})`;
}

export function drawSpeedHistogram(ctx, canvas, world) {
  const BIN_COUNT = 20;
  const MAX_SPEED = 25;
  const W = canvas.width;
  const H = canvas.height;

  ctx.clearRect(0, 0, W, H);

  ctx.fillStyle = "#1e1e1e";
  ctx.fillRect(0, 0, W, H);

  const bodies = world.bodies.filter(b => !b.fixed);
  const N = bodies.length;

  if (N === 0) return;

  const speeds = bodies.map(b => b.vel.length());
  const meanSpeed = speeds.reduce((sum, v) => sum + v, 0) / N;

  // Fixed histogram scales
  const maxSpeed = MAX_SPEED;
  const maxCount = N/3;
  const binWidth = maxSpeed / BIN_COUNT;

  const bins = new Array(BIN_COUNT).fill(0);

  for (const speed of speeds) {
    const index = Math.min(
      Math.floor(speed / binWidth),
      BIN_COUNT - 1
    );

    bins[index]++;
  }

  // Plot dimensions
  const left = 65;
  const right = W - 25;
  const top = 42;
  const bottom = H - 42;

  const plotW = right - left;
  const plotH = bottom - top;

  // Title
  ctx.fillStyle = "#d4d4d4";
  ctx.font = "bold 15px monospace";
  ctx.textAlign = "left";
  ctx.fillText("Particle Speed Distribution", left, 23);

  ctx.font = "12px monospace";
  ctx.fillText(
    `N = ${N}    Mean speed = ${meanSpeed.toFixed(2)}`,
    W - 330,
    23
  );

  // Horizontal grid lines
  ctx.font = "11px monospace";
  ctx.textAlign = "right";

  for (let i = 0; i <= 4; i++) {
    const value = maxCount * i / 4;
    const y = bottom - (value / maxCount) * plotH;

    ctx.strokeStyle = "#393939";
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(right, y);
    ctx.stroke();

    ctx.fillStyle = "#aaaaaa";
    ctx.fillText(value.toFixed(0), left - 8, y + 4);
  }

  // Histogram bars
  const barW = plotW / BIN_COUNT;

  for (let i = 0; i < BIN_COUNT; i++) {
    const barH = (bins[i] / maxCount) * plotH;

    ctx.fillStyle = "#3988c9";
    ctx.fillRect(
      left + i * barW + 1,
      bottom - barH,
      Math.max(0, barW - 2),
      barH
    );
  }

  // Mean speed marker
  const meanX = left + (meanSpeed / maxSpeed) * plotW;

  ctx.strokeStyle = "#f48771";
  ctx.lineWidth = 2;
  ctx.setLineDash([5, 4]);

  ctx.beginPath();
  ctx.moveTo(meanX, top);
  ctx.lineTo(meanX, bottom);
  ctx.stroke();

  ctx.setLineDash([]);

  // X-axis labels
  ctx.fillStyle = "#aaaaaa";
  ctx.font = "11px monospace";
  ctx.textAlign = "center";

  for (let i = 0; i <= 5; i++) {
    const speed = maxSpeed * i / 5;
    const x = left + (speed / maxSpeed) * plotW;

    ctx.fillText(speed.toFixed(1), x, bottom + 17);
  }

  // Axis labels
  ctx.fillStyle = "#d4d4d4";
  ctx.font = "12px monospace";

  ctx.textAlign = "center";
  ctx.fillText("Speed (m/s)", left + plotW / 2, H - 5);

  ctx.save();
  ctx.translate(15, top + plotH / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("Particle count", 0, 0);
  ctx.restore();

  // Mean speed legend
  ctx.textAlign = "right";
  ctx.fillStyle = "#f48771";
  ctx.fillText("Mean speed", right, top - 10);
}

export function draw(ctx, canvas, world, hud) {
  const cam = world.meta.camera;
  const spacing = world.meta.tickSpacing
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (world.meta.kind === "box") {
    const t_w = world.meta.w; const t_h = world.meta.h; const pad = 3;
    const cx = world.meta.cx; const cy = world.meta.cy;
    ctx.strokeStyle = "#6c3813"; ctx.lineWidth = 3; ctx.fillStyle = "#2e5456";
    ctx.beginPath();
    ctx.moveTo(cam.toScreenX(cx-t_w/2), cam.toScreenY(cy-t_h/2)); 
    ctx.lineTo(cam.toScreenX(cx+t_w/2), cam.toScreenY(cy-t_h/2)); 
    ctx.lineTo(cam.toScreenX(cx+t_w/2), cam.toScreenY(cy+t_h/2));
    ctx.lineTo(cam.toScreenX(cx-t_w/2), cam.toScreenY(cy+t_h/2));
    ctx.lineTo(cam.toScreenX(cx-t_w/2), cam.toScreenY(cy-t_h/2));
    ctx.stroke();
    ctx.fill();
  }

  if (world.meta.trail) {
    for (const b of world.bodies) {
      // trail
      if (b.trail.length > 1) {
        ctx.strokeStyle = speedColor(b, 15); ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cam.toScreenX(b.trail[0].x), cam.toScreenY(b.trail[0].y));
        for (let i = 1; i < b.trail.length; i++)
          ctx.lineTo(cam.toScreenX(b.trail[i].x), cam.toScreenY(b.trail[i].y));
        ctx.stroke();
      }
    }
  }

  for (const b of world.bodies) {
    // body
    ctx.beginPath();
    ctx.arc(cam.toScreenX(b.pos.x), cam.toScreenY(b.pos.y),
            Math.max(4, cam.toScreenLen(b.radius)), 0, Math.PI * 2);
    ctx.fillStyle = speedColor(b, 15); ctx.fill();
    // velocity vector
    if (world.meta.velVec) {
      const vs = world.meta.kind === "spring" ? 0.6 : 0.25;
      const tipX = cam.toScreenX(b.pos.x + b.vel.x * vs);
      const tipY = cam.toScreenY(b.pos.y + b.vel.y * vs);
      ctx.strokeStyle = "#9cdcfe"; ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cam.toScreenX(b.pos.x), cam.toScreenY(b.pos.y));
      ctx.lineTo(tipX, tipY); ctx.stroke();
    }
  }
  
  // HUD
  drawHud(ctx, canvas, world, hud)
}